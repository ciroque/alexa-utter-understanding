"use strict";
/**
 * Created by swagner on 10/29/16.
 */
class IntentRequestHandler {
    handleRequest(event, context) {
        return new Promise((resolve, reject) => {
            reject('Not Implemented');
        });
    }
}
exports.IntentRequestHandler = IntentRequestHandler;
//# sourceMappingURL=IntentRequestHandler.js.map