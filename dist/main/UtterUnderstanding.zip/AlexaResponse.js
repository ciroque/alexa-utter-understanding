/**
 * Created by swagner on 10/29/16.
 */
"use strict";
class AlexaResponse {
    constructor() {
    }
}
exports.AlexaResponse = AlexaResponse;
//# sourceMappingURL=AlexaResponse.js.map