/**
 * Created by swagner on 10/29/16.
 */
export declare class AlexaResponse {
    constructor();
}
