export declare class SpeechletOutputSpeech {
    text: string;
    type: string;
    static readonly defaultInstance: SpeechletOutputSpeech;
    constructor(text: string, type: string);
}
