import { SpeechletOutputSpeech } from './SpeechletOutputSpeech';
export declare class SpeechletReprompt {
    outputSpeech: SpeechletOutputSpeech;
    static readonly defaultInstance: SpeechletReprompt;
    constructor(outputSpeech: SpeechletOutputSpeech);
}
